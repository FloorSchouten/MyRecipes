<template>
  <h1>Cookies</h1>
</template>

<script>
export default {
  name: "Cookies",
};
</script>