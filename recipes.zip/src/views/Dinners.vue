<template>
  <h1>Dinners</h1>
</template>

<script>
export default {
  name: "Dinners",
};
</script>